import e from "/js/events.js?v=2.17";
export let game = new e;